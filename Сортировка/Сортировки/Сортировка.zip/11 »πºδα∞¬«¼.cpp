﻿#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <string>
#include <cmath>
using namespace std;
ifstream input("F:\\Учеба\\Задачи c++\\Сортировка\\Сортировка_ввод.txt"); //файл из которого берем данные 
ofstream output("F:\\Учеба\\Задачи c++\\Сортировка\\Сортировка_вывод.txt"); //файл в который будем записыать даннные
int tmp = 0;
struct date { //структура для даты
    int day, mon, year;
};

struct people { //структура для информации о человеке
    string name;
    string job;
    int exp;
    date dob;
    int pay;
};

date str_to_date(string s) { //перевод из строки в date
    date x;
    string t = s.substr(0, 2);//день
    x.day = atoi(t.c_str());//перевод
    t = s.substr(3, 2);//месяц
    x.mon = atoi(t.c_str());//перевод
    t = s.substr(6, 4);//год
    x.year = atoi(t.c_str());//перевод
    return x;
}
string str_to_data(string x) { //перевод из строки в информацию
    string s;
    while (tmp != min(x.size(), x.find(',', tmp))) { //т.к данные указаны через "," то применяем цикл
        s += x[tmp];
        tmp++;
    }
    tmp += 2;
    return s;
}
vector <people> inFile() { //заполняем вектор информацией о людях 
    vector<people> x;
    people temp;
    string s;
    while (input.peek() != EOF) {
        getline(input, s);
        temp.name = str_to_data(s); //получаем имя
        temp.job = str_to_data(s); //получаем профессию 
        temp.dob = str_to_date(str_to_data(s)); //получаем дату рождения
        temp.exp = atoi(str_to_data(s).c_str()); //получаем стаж
        temp.pay = atoi(str_to_data(s).c_str()); //получаем зарплату 
        tmp = 0; //обнуляем счетчик 
        x.push_back(temp); //записываем информацию 

    }
    return x; //возвращаем вектор 
}

void OutFile(people x) { //Функция записи данных в файл
    output << x.name << ", ";
    output << x.job << ", ";
    if (x.dob.day < 10) output << '0' << x.dob.day << '.';
    else output << x.dob.day << '.';
    if (x.dob.mon < 10) output << '0' << x.dob.mon << '.';
    else output << x.dob.mon << '.';
    output << x.dob.year << ", ";
    output << x.exp << ", ";
    output << x.pay << '\n';
}
bool operator <(people x, people y) { //переопределяем оператор "<"
    if (x.job < y.job) return true;
    if (x.job == y.job && x.exp < y.exp) return true;
    if (x.job == y.job && x.exp == y.exp && x.pay < y.pay) return true;
    else return false;
}
void Bubble(vector<people>& x, int size) { //Функция сортировки
    int n = size;
    for (int i = 0; i < n - 1; i++) {
        for (int j = n - 1; j > n; j--) {
            if (x[j] < x[j - 1]) {
                swap(x[j - 1], x[j]);
            }
        }
    }


}
int main()
{
    setlocale(LC_ALL, "rus");
    vector<people> x;
    x = inFile();
    Bubble(x, x.size());
    for (int i = 0; i < x.size(); i++) {
        OutFile(x[i]);
    }
    system("pause");
}





